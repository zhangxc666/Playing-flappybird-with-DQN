import torch
import torch.nn.functional as F

class Qnet(torch.nn.Module):
    ''' 只有一层隐藏层的Q网络 '''
    def __init__(self, state_dim, hidden_dim,mid_dim, action_dim):
        super(Qnet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc3 = torch.nn.Linear(hidden_dim, mid_dim)
        self.fc2 = torch.nn.Linear(mid_dim, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))  # 隐藏层使用ReLU激活函数
        return self.fc2(F.relu(self.fc3(x)))
